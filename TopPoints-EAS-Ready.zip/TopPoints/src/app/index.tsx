import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import { Alert, ActivityIndicator, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from 'react-native';
import { supabase } from '../lib/supabase';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [register, setRegister] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) router.replace('/(tabs)');
    });
  }, []);

  const submit = async () => {
    if (!email.trim() || password.length < 6 || (register && !fullName.trim())) {
      Alert.alert('تنبيه', register ? 'اكتب الاسم والبريد وكلمة مرور من 6 أحرف على الأقل.' : 'اكتب البريد وكلمة المرور بشكل صحيح.');
      return;
    }
    setLoading(true);
    try {
      if (register) {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: fullName.trim() } },
        });
        if (error) throw error;
        if (data.session) {
          router.replace('/(tabs)');
        } else {
          Alert.alert('تم إنشاء الحساب', 'إذا كان تأكيد البريد مفعّلًا في Supabase، افتح بريدك وأكّد الحساب ثم سجّل الدخول.');
          setRegister(false);
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        router.replace('/(tabs)');
      }
    } catch (e: any) {
      Alert.alert('تعذر المتابعة', e?.message ?? 'حدث خطأ غير متوقع.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <View style={styles.logo}><Text style={styles.logoText}>TP</Text></View>
        <Text style={styles.title}>TopPoints</Text>
        <Text style={styles.subtitle}>اجمع نقاطك واستبدلها بمكافآت</Text>
        <View style={styles.card}>
          {register && <>
            <Text style={styles.label}>الاسم</Text>
            <TextInput value={fullName} onChangeText={setFullName} placeholder="اسمك" placeholderTextColor="#9CA3AF" style={styles.input} textAlign="right" />
          </>}
          <Text style={styles.label}>البريد الإلكتروني</Text>
          <TextInput value={email} onChangeText={setEmail} placeholder="example@email.com" placeholderTextColor="#9CA3AF" autoCapitalize="none" keyboardType="email-address" style={styles.input} textAlign="right" />
          <Text style={styles.label}>كلمة المرور</Text>
          <TextInput value={password} onChangeText={setPassword} placeholder="6 أحرف أو أكثر" placeholderTextColor="#9CA3AF" secureTextEntry style={styles.input} textAlign="right" />
          <Pressable style={styles.button} onPress={submit} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>{register ? 'إنشاء حساب' : 'تسجيل الدخول'}</Text>}
          </Pressable>
          <Pressable onPress={() => setRegister(!register)} style={styles.demo}>
            <Text style={styles.demoText}>{register ? 'عندي حساب بالفعل' : 'إنشاء حساب جديد'}</Text>
          </Pressable>
        </View>
        <Text style={styles.note}>بياناتك تُحفظ في Supabase بشكل مباشر.</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F7F8FC' },
  container: { flex: 1, padding: 24, justifyContent: 'center', direction: 'rtl' },
  logo: { width: 76, height: 76, borderRadius: 24, backgroundColor: '#5B4BDB', alignSelf: 'center', alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  logoText: { color: '#fff', fontSize: 27, fontWeight: '800' },
  title: { textAlign: 'center', fontSize: 30, fontWeight: '800', color: '#16162A' },
  subtitle: { textAlign: 'center', color: '#6B7280', marginTop: 8, marginBottom: 28, fontSize: 15 },
  card: { backgroundColor: '#fff', borderRadius: 24, padding: 20, elevation: 2 },
  label: { color: '#374151', fontWeight: '700', marginBottom: 8, textAlign: 'right' },
  input: { height: 52, borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 14, paddingHorizontal: 14, marginBottom: 16, color: '#111827', backgroundColor: '#FAFAFC' },
  button: { height: 52, borderRadius: 14, backgroundColor: '#5B4BDB', alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  demo: { alignItems: 'center', paddingTop: 18 },
  demoText: { color: '#5B4BDB', fontWeight: '700' },
  note: { textAlign: 'center', color: '#9CA3AF', fontSize: 12, marginTop: 18 },
});
