import { Alert, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';

type Task = { id: string; title: string; description: string; points: number; icon: string };
export default function Tasks() {
  const [items, setItems] = useState<Task[]>([]);
  const load = async () => {
    const { data } = await supabase.from('tasks').select('id,title,description,points,icon').eq('active', true).order('created_at', { ascending: true });
    setItems(data ?? []);
  };
  useEffect(() => { load(); }, []);
  const complete = async (id: string) => {
    const { error } = await supabase.rpc('complete_task', { p_task_id: id });
    if (error) return Alert.alert('تعذر إكمال المهمة', error.message);
    Alert.alert('تمت المهمة 🎉', 'تمت إضافة النقاط إلى رصيدك.');
    load();
  };
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.container}>
    <Text style={styles.title}>المهام</Text><Text style={styles.subtitle}>أنجز المهام واجمع المزيد من النقاط</Text>
    {items.map((item) => <View style={styles.card} key={item.id}>
      <View style={styles.icon}><Text style={{fontSize:23}}>{item.icon}</Text></View>
      <View style={{flex:1}}><Text style={styles.name}>{item.title}</Text><Text style={styles.desc}>{item.description}</Text><Text style={styles.points}>+{item.points} نقطة</Text></View>
      <Pressable onPress={() => complete(item.id)} style={styles.button}><Text style={styles.buttonText}>ابدأ</Text></Pressable>
    </View>)}
  </ScrollView></SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#F7F8FC'},container:{padding:20,paddingBottom:100,direction:'rtl'},title:{fontSize:28,fontWeight:'900',color:'#16162A',textAlign:'right'},subtitle:{color:'#6B7280',textAlign:'right',marginTop:6,marginBottom:20},card:{backgroundColor:'#fff',borderRadius:18,padding:14,marginBottom:10,flexDirection:'row-reverse',alignItems:'center'},icon:{width:48,height:48,borderRadius:15,backgroundColor:'#F2F1FF',alignItems:'center',justifyContent:'center',marginLeft:12},name:{fontSize:15,fontWeight:'800',color:'#1F2937',textAlign:'right'},desc:{fontSize:12,color:'#6B7280',textAlign:'right',marginTop:4},points:{fontSize:12,fontWeight:'800',color:'#5B4BDB',textAlign:'right',marginTop:6},button:{backgroundColor:'#5B4BDB',paddingHorizontal:13,paddingVertical:9,borderRadius:10},buttonText:{color:'#fff',fontWeight:'800'}});
