import { Tabs } from 'expo-router';

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#5B4BDB',
        tabBarInactiveTintColor: '#9CA3AF',
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
        tabBarStyle: { height: 68, paddingTop: 6, paddingBottom: 8 },
      }}
    >
      <Tabs.Screen name="index" options={{ title: 'الرئيسية', tabBarIcon: () => '⌂' }} />
      <Tabs.Screen name="tasks" options={{ title: 'المهام', tabBarIcon: () => '✓' }} />
      <Tabs.Screen name="rewards" options={{ title: 'المكافآت', tabBarIcon: () => '🎁' }} />
      <Tabs.Screen name="history" options={{ title: 'السجل', tabBarIcon: () => '▤' }} />
      <Tabs.Screen name="account" options={{ title: 'الحساب', tabBarIcon: () => '♙' }} />
    </Tabs>
  );
}