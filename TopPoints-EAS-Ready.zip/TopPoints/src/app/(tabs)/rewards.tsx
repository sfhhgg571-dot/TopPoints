import { Alert, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';

type Reward = { id: string; title: string; description: string; cost: number; icon: string; stock: number | null };
export default function Rewards() {
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [balance, setBalance] = useState(0);
  const load = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const [{ data: profile }, { data }] = await Promise.all([
      supabase.from('profiles').select('points_balance').eq('id', user.id).single(),
      supabase.from('rewards').select('id,title,description,cost,icon,stock').eq('active', true).order('created_at', { ascending: true }),
    ]);
    setBalance(profile?.points_balance ?? 0); setRewards(data ?? []);
  };
  useEffect(() => { load(); }, []);
  const redeem = async (id: string) => {
    const { error } = await supabase.rpc('redeem_reward', { p_reward_id: id });
    if (error) return Alert.alert('تعذر الاستبدال', error.message);
    Alert.alert('تم الاستبدال 🎁', 'تم خصم النقاط من رصيدك.');
    load();
  };
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.container}>
    <Text style={styles.title}>المكافآت</Text>
    <View style={styles.balance}><Text style={styles.balanceLabel}>رصيدك الحالي</Text><Text style={styles.balancePoints}>{balance.toLocaleString('ar-IQ')} نقطة</Text></View>
    {rewards.map((reward) => <View style={styles.card} key={reward.id}>
      <View style={styles.icon}><Text style={{fontSize:25}}>{reward.icon}</Text></View>
      <View style={{flex:1}}><Text style={styles.name}>{reward.title}</Text><Text style={styles.desc}>{reward.description}</Text><Text style={styles.cost}>{reward.cost.toLocaleString('ar-IQ')} نقطة {reward.stock !== null ? `• المتوفر ${reward.stock}` : ''}</Text></View>
      <Pressable style={styles.button} onPress={() => redeem(reward.id)}><Text style={styles.buttonText}>استبدال</Text></Pressable>
    </View>)}
  </ScrollView></SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#F7F8FC'},container:{padding:20,paddingBottom:100,direction:'rtl'},title:{fontSize:28,fontWeight:'900',color:'#16162A',textAlign:'right',marginBottom:18},balance:{backgroundColor:'#16162A',borderRadius:20,padding:20,marginBottom:18},balanceLabel:{color:'#D1D5DB',textAlign:'right'},balancePoints:{color:'#fff',fontSize:28,fontWeight:'900',textAlign:'right',marginTop:5},card:{backgroundColor:'#fff',borderRadius:18,padding:14,marginBottom:10,flexDirection:'row-reverse',alignItems:'center'},icon:{width:50,height:50,borderRadius:15,backgroundColor:'#F2F1FF',alignItems:'center',justifyContent:'center',marginLeft:12},name:{fontWeight:'800',color:'#1F2937',textAlign:'right'},desc:{color:'#6B7280',fontSize:11,textAlign:'right',marginTop:4},cost:{color:'#5B4BDB',fontWeight:'700',fontSize:12,textAlign:'right',marginTop:5},button:{backgroundColor:'#5B4BDB',paddingHorizontal:12,paddingVertical:9,borderRadius:10},buttonText:{color:'#fff',fontWeight:'800'}});
