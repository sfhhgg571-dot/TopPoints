import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import { Alert, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { supabase } from '../../lib/supabase';
export default function Account() {
  const [name, setName] = useState('مستخدم'); const [email, setEmail] = useState('');
  useEffect(() => { (async () => { const { data:{user} } = await supabase.auth.getUser(); if (!user) return router.replace('/'); setEmail(user.email ?? ''); const { data } = await supabase.from('profiles').select('full_name').eq('id', user.id).single(); setName(data?.full_name || user.email?.split('@')[0] || 'مستخدم'); })(); }, []);
  const logout = async () => { await supabase.auth.signOut(); router.replace('/'); };
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.container}>
    <Text style={styles.title}>الحساب</Text><View style={styles.profile}><View style={styles.avatar}><Text style={styles.avatarText}>{name.slice(0,1)}</Text></View><Text style={styles.name}>{name}</Text><Text style={styles.email}>{email}</Text></View>
    <View style={styles.card}><View style={styles.item}><Text style={styles.itemText}>👤  المعلومات الشخصية</Text><Text style={styles.arrow}>‹</Text></View><View style={styles.item}><Text style={styles.itemText}>🔒  الخصوصية والأمان</Text><Text style={styles.arrow}>‹</Text></View><View style={styles.item}><Text style={styles.itemText}>❓  المساعدة والدعم</Text><Text style={styles.arrow}>‹</Text></View></View>
    <Pressable style={styles.logout} onPress={() => Alert.alert('تسجيل الخروج','هل تريد تسجيل الخروج؟',[{text:'إلغاء',style:'cancel'},{text:'خروج',style:'destructive',onPress:logout}])}><Text style={styles.logoutText}>تسجيل الخروج</Text></Pressable>
    <Text style={styles.version}>TopPoints v1.1 — Supabase</Text>
  </ScrollView></SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#F7F8FC'},container:{padding:20,paddingBottom:100,direction:'rtl'},title:{fontSize:28,fontWeight:'900',color:'#16162A',textAlign:'right',marginBottom:18},profile:{backgroundColor:'#fff',borderRadius:22,padding:24,alignItems:'center',marginBottom:15},avatar:{width:76,height:76,borderRadius:25,backgroundColor:'#E8E5FF',alignItems:'center',justifyContent:'center',marginBottom:10},avatarText:{fontSize:28,fontWeight:'900',color:'#5B4BDB'},name:{fontSize:20,fontWeight:'900',color:'#16162A'},email:{color:'#9CA3AF',marginTop:4},card:{backgroundColor:'#fff',borderRadius:20,paddingHorizontal:15},item:{height:62,borderBottomWidth:1,borderBottomColor:'#F0F0F3',flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-between'},itemText:{fontWeight:'700',color:'#374151',fontSize:14},arrow:{fontSize:25,color:'#9CA3AF'},logout:{marginTop:16,height:52,borderRadius:15,backgroundColor:'#FEE2E2',alignItems:'center',justifyContent:'center'},logoutText:{color:'#DC2626',fontWeight:'800'},version:{textAlign:'center',color:'#9CA3AF',fontSize:11,marginTop:18}});
