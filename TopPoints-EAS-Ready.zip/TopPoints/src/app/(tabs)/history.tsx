import { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { supabase } from '../../lib/supabase';

type Row = { id: string; kind: string; amount: number; title: string; created_at: string };
export default function History() {
  const [rows, setRows] = useState<Row[]>([]);
  useEffect(() => {
    supabase.from('transactions').select('id,kind,amount,title,created_at').order('created_at', { ascending: false }).limit(100).then(({ data }) => setRows(data ?? []));
  }, []);
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.container}>
    <Text style={styles.title}>سجل العمليات</Text><View style={styles.card}>
      {rows.length === 0 ? <Text style={styles.empty}>لا توجد عمليات بعد.</Text> : rows.map((row, i) => {
        const positive = row.amount > 0;
        return <View key={row.id} style={[styles.row, i === rows.length - 1 && {borderBottomWidth:0}]}>
          <View style={styles.dot}><Text>{positive ? '↑' : '↓'}</Text></View>
          <View style={{flex:1}}><Text style={styles.name}>{row.title}</Text><Text style={styles.date}>{new Date(row.created_at).toLocaleString('ar-IQ')}</Text></View>
          <Text style={[styles.amount, !positive && {color:'#EF4444'}]}>{positive ? '+' : ''}{row.amount.toLocaleString('ar-IQ')}</Text>
        </View>;
      })}
    </View>
  </ScrollView></SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#F7F8FC'},container:{padding:20,paddingBottom:100,direction:'rtl'},title:{fontSize:28,fontWeight:'900',color:'#16162A',textAlign:'right',marginBottom:18},card:{backgroundColor:'#fff',borderRadius:20,paddingHorizontal:15},row:{minHeight:76,borderBottomWidth:1,borderBottomColor:'#F0F0F3',flexDirection:'row-reverse',alignItems:'center'},dot:{width:40,height:40,borderRadius:14,backgroundColor:'#F2F1FF',alignItems:'center',justifyContent:'center',marginLeft:12},name:{fontWeight:'800',color:'#1F2937',textAlign:'right'},date:{fontSize:11,color:'#9CA3AF',textAlign:'right',marginTop:4},amount:{fontWeight:'900',color:'#10B981',fontSize:15},empty:{textAlign:'center',padding:30,color:'#9CA3AF'}});
