import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import { Alert, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { supabase } from '../../lib/supabase';

type Task = { id: string; title: string; description: string; points: number; icon: string };

export default function Home() {
  const [name, setName] = useState('مستخدم');
  const [balance, setBalance] = useState(0);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return router.replace('/');
    const [{ data: profile }, { data: taskData }] = await Promise.all([
      supabase.from('profiles').select('full_name, points_balance').eq('id', user.id).single(),
      supabase.from('tasks').select('id,title,description,points,icon').eq('active', true).order('created_at', { ascending: true }).limit(3),
    ]);
    setName(profile?.full_name || user.email?.split('@')[0] || 'مستخدم');
    setBalance(profile?.points_balance ?? 0);
    setTasks(taskData ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const complete = async (id: string) => {
    const { error } = await supabase.rpc('complete_task', { p_task_id: id });
    if (error) return Alert.alert('تعذر إكمال المهمة', error.message);
    Alert.alert('تمت المهمة 🎉', 'تمت إضافة النقاط إلى رصيدك.');
    load();
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <View><Text style={styles.hello}>أهلًا بك 👋</Text><Text style={styles.name}>{name}</Text></View>
          <View style={styles.avatar}><Text style={styles.avatarText}>{name.slice(0, 1)}</Text></View>
        </View>
        <View style={styles.balance}>
          <Text style={styles.balanceLabel}>رصيد النقاط</Text>
          <Text style={styles.points}>{balance.toLocaleString('ar-IQ')}</Text>
          <Text style={styles.small}>نقطة متاحة للاستبدال</Text>
          <Pressable onPress={() => router.push('/(tabs)/rewards')} style={styles.balanceButton}><Text style={styles.balanceButtonText}>استبدال النقاط</Text></Pressable>
        </View>
        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>المهام</Text><Pressable onPress={() => router.push('/(tabs)/tasks')}><Text style={styles.more}>عرض الكل</Text></Pressable></View>
        {loading ? <Text style={styles.empty}>جاري التحميل...</Text> : tasks.map((task) => (
          <View key={task.id} style={styles.task}>
            <View style={styles.taskIcon}><Text>{task.icon}</Text></View>
            <View style={{ flex: 1 }}><Text style={styles.taskTitle}>{task.title}</Text><Text style={styles.taskPoints}>+{task.points} نقطة</Text></View>
            <Pressable style={styles.done} onPress={() => complete(task.id)}><Text style={styles.doneText}>ابدأ</Text></Pressable>
          </View>
        ))}
        <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>اختصارات</Text></View>
        <View style={styles.grid}>
          <Pressable style={styles.quick} onPress={() => router.push('/(tabs)/rewards')}><Text style={styles.quickIcon}>🎁</Text><Text style={styles.quickText}>المكافآت</Text></Pressable>
          <Pressable style={styles.quick} onPress={() => router.push('/(tabs)/history')}><Text style={styles.quickIcon}>📋</Text><Text style={styles.quickText}>العمليات</Text></Pressable>
          <Pressable style={styles.quick} onPress={() => router.push('/(tabs)/tasks')}><Text style={styles.quickIcon}>⭐</Text><Text style={styles.quickText}>المهام</Text></Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:'#F7F8FC'},container:{padding:20,paddingBottom:100,direction:'rtl'},header:{flexDirection:'row-reverse',justifyContent:'space-between',alignItems:'center',marginBottom:22},hello:{color:'#6B7280',fontSize:14,textAlign:'right'},name:{color:'#16162A',fontSize:22,fontWeight:'800',textAlign:'right',marginTop:3},avatar:{width:48,height:48,borderRadius:16,backgroundColor:'#E8E5FF',alignItems:'center',justifyContent:'center'},avatarText:{color:'#5B4BDB',fontWeight:'800',fontSize:18},balance:{backgroundColor:'#5B4BDB',borderRadius:24,padding:22,marginBottom:26},balanceLabel:{color:'#EAE8FF',textAlign:'right'},points:{color:'#fff',fontSize:38,fontWeight:'900',textAlign:'right',marginTop:2},small:{color:'#EAE8FF',textAlign:'right',fontSize:12},balanceButton:{backgroundColor:'#fff',borderRadius:12,paddingVertical:11,paddingHorizontal:16,alignSelf:'flex-start',marginTop:18},balanceButtonText:{color:'#5B4BDB',fontWeight:'800'},sectionHeader:{flexDirection:'row-reverse',justifyContent:'space-between',alignItems:'center',marginBottom:12},sectionTitle:{fontSize:18,fontWeight:'800',color:'#16162A',textAlign:'right'},more:{color:'#5B4BDB',fontWeight:'700'},task:{flexDirection:'row-reverse',alignItems:'center',backgroundColor:'#fff',padding:14,borderRadius:18,marginBottom:10},taskIcon:{width:44,height:44,borderRadius:14,backgroundColor:'#F2F1FF',alignItems:'center',justifyContent:'center',marginLeft:12},taskTitle:{fontWeight:'700',color:'#1F2937',textAlign:'right'},taskPoints:{color:'#5B4BDB',fontSize:12,marginTop:4,textAlign:'right'},done:{borderRadius:10,backgroundColor:'#F2F1FF',paddingHorizontal:13,paddingVertical:9},doneText:{color:'#5B4BDB',fontWeight:'800'},grid:{flexDirection:'row-reverse',gap:10},quick:{backgroundColor:'#fff',flex:1,minHeight:92,borderRadius:18,alignItems:'center',justifyContent:'center'},quickIcon:{fontSize:25,marginBottom:7},quickText:{fontWeight:'700',color:'#374151',fontSize:12},empty:{textAlign:'center',color:'#9CA3AF',padding:20}
});
