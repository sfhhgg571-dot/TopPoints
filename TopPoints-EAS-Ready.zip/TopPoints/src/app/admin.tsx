import { router } from 'expo-router';
import { Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';

const stats = [['👥','المستخدمون','1,284'],['⭐','النقاط المتداولة','384,520'],['🎁','المكافآت','96'],['📈','عمليات اليوم','128']];

export default function Admin() {
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()}><Text style={styles.back}>رجوع</Text></Pressable>
          <Text style={styles.title}>لوحة التحكم</Text>
        </View>
        <Text style={styles.subtitle}>ملخص تجريبي للإدارة</Text>
        <View style={styles.grid}>
          {stats.map(([icon, name, value]) => (
            <View style={styles.stat} key={name}>
              <Text style={styles.icon}>{icon}</Text><Text style={styles.value}>{value}</Text><Text style={styles.label}>{name}</Text>
            </View>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>إجراءات الإدارة</Text>
          {['إدارة المستخدمين','إدارة المهام','إدارة المكافآت','مراجعة العمليات'].map(x => (
            <View style={styles.row} key={x}><Text style={styles.chev}>‹</Text><Text style={styles.rowText}>{x}</Text></View>
          ))}
        </View>
        <View style={styles.notice}><Text style={styles.noticeTitle}>تنبيه</Text><Text style={styles.noticeText}>هذه اللوحة محلية للتجربة فقط. قبل الإطلاق يجب إضافة تسجيل دخول للمشرف وصلاحيات وقاعدة بيانات وخادم API.</Text></View>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#F7F8FC'},container:{padding:20,paddingBottom:60,direction:'rtl'},header:{flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-between'},back:{color:'#5B4BDB',fontWeight:'800'},title:{fontSize:28,fontWeight:'900',color:'#16162A',textAlign:'right'},subtitle:{color:'#6B7280',textAlign:'right',marginTop:6,marginBottom:18},
 grid:{flexDirection:'row-reverse',flexWrap:'wrap',gap:10},stat:{width:'48%',backgroundColor:'#fff',borderRadius:18,padding:16,minHeight:120},icon:{fontSize:23,textAlign:'right'},value:{fontSize:24,fontWeight:'900',color:'#16162A',textAlign:'right',marginTop:10},label:{fontSize:12,color:'#6B7280',textAlign:'right',marginTop:4},
 card:{backgroundColor:'#fff',borderRadius:20,paddingHorizontal:16,marginTop:16},cardTitle:{fontSize:17,fontWeight:'900',color:'#16162A',textAlign:'right',paddingVertical:16},row:{height:56,borderTopWidth:1,borderTopColor:'#F0F0F3',flexDirection:'row',justifyContent:'space-between',alignItems:'center'},rowText:{fontWeight:'700',color:'#374151'},chev:{fontSize:25,color:'#9CA3AF'},notice:{backgroundColor:'#FFF7ED',borderRadius:18,padding:16,marginTop:16},noticeTitle:{fontWeight:'900',color:'#9A3412',textAlign:'right'},noticeText:{color:'#9A3412',fontSize:12,lineHeight:19,textAlign:'right',marginTop:6}
});