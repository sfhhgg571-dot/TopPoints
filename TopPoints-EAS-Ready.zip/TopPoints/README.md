# TopPoints — Supabase connected

نسخة TopPoints مرتبطة مباشرة بمشروع Supabase.

## قبل التشغيل

1. ثبّت Node.js 20+.
2. من داخل مجلد المشروع شغّل `npm install`.
3. شغّل `npx expo start`.
4. سجّل حسابًا من شاشة التطبيق.

## Supabase

النسخة تستخدم الـ Publishable Key داخل تطبيق الهاتف. لا تضع Service Role Key داخل التطبيق.

قاعدة البيانات المطلوبة هي الجداول والـ RPC التي تم تنفيذها في Supabase:
- profiles
- tasks
- rewards
- transactions
- complete_task(uuid)
- redeem_reward(uuid)
